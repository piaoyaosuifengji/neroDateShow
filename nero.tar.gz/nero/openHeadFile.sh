gedit   ./src/NeuralNetwork/NeuralNetwork.h  ./src/NeuralNetwork/NeuralOperating.h  ./src/tools/Nero_IO.h    ./src/common/type.h  ./src/common/NeroMsgId.h ./src/common/NeroError.h  ./src/tools/Nero_Task.h

