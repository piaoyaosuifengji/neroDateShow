



gedit ./src/MainWindow.c  ./src/NeuralNetwork/NeuralNetwork.c  ./src/NeuralNetwork/NeuralOperating.c  ./src/tools/Nero_IO.c  ./src/tools/Nero_Task.c


#mydir= $(pwd)
#echo $mydir


#sudo  -i
#cd dir
