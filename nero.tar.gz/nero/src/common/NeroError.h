
#ifndef ERROR_h
#define ERROR_h




/*这个文件定义所有的错误情况列表*/
#define nero_msg_unknowError		-1
#define nero_msg_fail		0
#define nero_msg_ok		1

#define nero_msg_ParameterError		20  /*参数检查错误*/






#define NeroYES   100
#define NeroNO    101




#define Process_msg_CreateNewObj   500























#endif
