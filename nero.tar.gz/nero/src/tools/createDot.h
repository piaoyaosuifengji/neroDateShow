#ifndef CREATEDOT_H
#define CREATEDOT_H

#include "../common/type.h"
#include "../NeuralNetwork/NeuralNetwork.h"




void createNeroNetDotGraph(NeuronObject *GodNero,  char *fileName);


void createNeroNetDotGraphForWords(NeuronObject *GodNero,  char *fileName);






















#endif
